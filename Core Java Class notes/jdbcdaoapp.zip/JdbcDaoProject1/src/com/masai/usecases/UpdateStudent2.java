package com.masai.usecases;

import java.util.Scanner;

import com.masai.dao.StudentDao;
import com.masai.dao.StudentDaoImpl;
import com.masai.exceptions.StudentException;
import com.masai.model.Student;

public class UpdateStudent2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter roll to update student");
		int roll= sc.nextInt();
		
		
		StudentDao dao =new StudentDaoImpl();
		
		try {
			Student existingStudent= dao.getStudentByRoll(roll);
			
			System.out.println("Enter Marks:");
			int marks= sc.nextInt();
			
			
			existingStudent.setMarks(marks);
			
			
			boolean f= dao.updateStudent(existingStudent);
			
			if(f)
				System.out.println("Updated..");
			else
				System.out.println("not updated..");
			
			
			
		} catch (StudentException e) {
			System.out.println(e.getMessage());
		}
		

	}

}
