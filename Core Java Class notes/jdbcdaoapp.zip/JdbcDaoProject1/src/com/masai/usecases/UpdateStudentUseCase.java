package com.masai.usecases;

import com.masai.dao.StudentDao;
import com.masai.dao.StudentDaoImpl;
import com.masai.exceptions.StudentException;
import com.masai.model.Student;

public class UpdateStudentUseCase {

	public static void main(String[] args) {
		
		Student s1 = new Student(100, "AMIT", 880);
		
		
		StudentDao dao = new StudentDaoImpl();
		
		try {
			boolean f= dao.updateStudent(s1);
			
			if(f)
				System.out.println("Student Updated...");
			
		} catch (StudentException e) {
			
			System.out.println(e.getMessage());
		}
		
		
		
	}

}
