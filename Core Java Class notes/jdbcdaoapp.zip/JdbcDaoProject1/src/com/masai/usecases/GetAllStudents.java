package com.masai.usecases;

import java.util.Collections;
import java.util.List;

import com.masai.dao.StudentDao;
import com.masai.dao.StudentDaoImpl;
import com.masai.model.Student;

public class GetAllStudents {

	public static void main(String[] args) {
		
		StudentDao dao = new StudentDaoImpl();
		
		List<Student> students= dao.getAllStudents();
		
		Collections.sort(students, (s1,s2) -> s1.getMarks() > s2.getMarks() ? +1: -1);
		
		students.forEach(s ->{
			
			System.out.println("Roll is :"+s.getRoll());
			System.out.println("Name is :"+s.getName());
			System.out.println("Marks is :"+s.getMarks());
			
			System.out.println("=========================");
			
		});
		
		
		
	}

}
