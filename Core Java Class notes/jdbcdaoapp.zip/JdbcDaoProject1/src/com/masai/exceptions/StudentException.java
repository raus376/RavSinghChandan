package com.masai.exceptions;

public class StudentException extends Exception{

	public StudentException() {
		
	}
	
	public StudentException(String message) {
		super(message);
	}

	
}
